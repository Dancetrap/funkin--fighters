# Funkin' Fighters
Based off of the Friday Night Finder that I have made. Funkin' Fighters have you build a team of 20 funkers, and battle other teams in a battle of chance
